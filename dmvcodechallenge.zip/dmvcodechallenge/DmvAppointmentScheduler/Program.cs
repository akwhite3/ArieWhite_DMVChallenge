﻿using System;
using System.IO;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace DmvAppointmentScheduler
{
    class Program
    {
        public static Random random = new Random();
        public static List<Appointment> appointmentList = new List<Appointment>();
        static void Main(string[] args)
        {
            CustomerList customers = ReadCustomerData();
            TellerList tellers = ReadTellerData();
            Calculation(customers, tellers);
            OutputTotalLengthToConsole();

        }
        private static CustomerList ReadCustomerData()
        {
            string fileName = "CustomerData.json";
            string path = Path.Combine(Environment.CurrentDirectory, @"InputData\", fileName);
            string jsonString = File.ReadAllText(path);
            CustomerList customerData = JsonConvert.DeserializeObject<CustomerList>(jsonString);
            return customerData;

        }
        private static TellerList ReadTellerData()
        {
            string fileName = "TellerData.json";
            string path = Path.Combine(Environment.CurrentDirectory, @"InputData\", fileName);
            string jsonString = File.ReadAllText(path);
            TellerList tellerData = JsonConvert.DeserializeObject<TellerList>(jsonString);
            return tellerData;

        }
        static void Calculation(CustomerList customers, TellerList tellers)
        {
            //initialize arrays to hold values for comparison
            double[] tellerTime = new double[150];
            double[] possibleTime = new double[150];
            for (int i = 0; i < 150; i++)
            {
                tellerTime[i] = 0;
                possibleTime[i] = 0;
            }

            //place each customer in line one at a time
            foreach (Customer customer in customers.Customer)
            {
                double thisDuration = Convert.ToDouble(customer.duration);
                int customerType = Convert.ToInt32(customer.type);

                int j = 0;

                //calculate the time the customer will take at each teller
                foreach (Teller teller in tellers.Teller)
                {
                    int tellerType = Convert.ToInt32(teller.specialtyType);

                    if (customerType == tellerType)
                    {
                        double multiplier = Convert.ToDouble(teller.multiplier);
                        possibleTime[j] = tellerTime[j] + (thisDuration * multiplier);
                    }
                    else
                    {
                        possibleTime[j] = tellerTime[j] + thisDuration;
                    }
                    j++;
                }

                //find the teller with the least amount of time 
                var min = possibleTime[0];
                int tellerIndex = 0;
                for (int k = 0; k < 150; k++)
                {
                    if (min > possibleTime[k] && possibleTime[k] != 0)
                    {
                        min = possibleTime[k];
                        tellerIndex = k;
                    }
                }

                //update the new teller time
                tellerTime[tellerIndex] = possibleTime[tellerIndex];

                //place customer in the line 
                var appointment = new Appointment(customer, tellers.Teller[tellerIndex]);
                appointmentList.Add(appointment);
            }
        }
        static void OutputTotalLengthToConsole()
        {
            var tellerAppointments =
                from appointment in appointmentList
                group appointment by appointment.teller into tellerGroup
                select new
                {
                    teller = tellerGroup.Key,
                    totalDuration = tellerGroup.Sum(x => x.duration),
                };
            var max = tellerAppointments.OrderBy(i => i.totalDuration).LastOrDefault();
            Console.WriteLine("Teller " + max.teller.id + " will work for " + max.totalDuration + " minutes!");
        }

    }
}
